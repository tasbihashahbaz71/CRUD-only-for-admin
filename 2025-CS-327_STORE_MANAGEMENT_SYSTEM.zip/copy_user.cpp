//                                           User signed in successfully ;)llllll
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <cstdlib>
#include <fstream>

using namespace std;

// VARIABLES
int n;
const int MAX_PRO = 50;
string proID[MAX_PRO];
string proName[MAX_PRO];
float proprice[MAX_PRO];
int proQuantity[MAX_PRO];

const int MAX_USERS = 15;
string employeeName[MAX_USERS];
string employeeID[MAX_USERS];
string employeeSalary[MAX_USERS];
int salesmanCount = 0;

// VARIABLES FOR SIGN-IN AND SING-UP
string Usernames[MAX_USERS];
string Passwords[MAX_USERS];
string userUsernames[MAX_USERS];
string userPasswords[MAX_USERS];

int proCount = 0;
int employeeCount = 0;
int userCount = 0;

// FUNCTION DECLARATIONS
bool checkpassword(string password);
bool checkusername(string username);
bool checkChoice(string choice);
bool checkChoice(float choice);
bool checkChoice(int choice);
void adminmenu();
void updateProduct();
void deleteProduct();
void userSignup();
bool userLogin();
void viewProduct();
void signup();
bool login();
void searchProduct();
void addProduct();
void bill();
void userMenu();
void menu();
void header();
void loadUsersFromFile();
void saveUsersToFile();
void addEmployee();
void viewEmployee();

// MAIN FUNC.
int main()
{
    loadUsersFromFile();
    header();
    menu();
    return 0;
}
// ----------------------------------------------------------------

// LOGIN FUNCTION OF ADMIN
bool login()
{
    bool isFound = false;
    string username2, password2;
    int idx = -1;
    cout << "\n\n\n \t\t\t  ============================================================== \n   ";
    cout << "       \t\t\t\t       LOG IN PAGE FOR ADMIN                      ";
    cout << " \n\t\t\t  ==============================================================" << endl;

    while (true)
    {
        cout << "\nEnter Username: ";
        cin >> username2;

        cout << "\nEnter Password: ";
        cin >> password2;

        // Condition to check username and password for admin
        if (username2 == "tasbiha" && password2 == "trash@4")
        {
            cout << "\n   ================================= \n  |  Admin Logged in Successfully.  |\n   =================================";
            return true;
        }
        else
        {
            cout << "\nInvalid Username or Password!\n";
            return false;
        }
    }
}

// ----------------------------------------------------------------

// USER SIGN UP AND SIGN IN
void userSignup()
{
    string username, password;
    string confirmPassword;

    if (userCount >= MAX_USERS) // Condition to check user limit
    {
        cout << "\nCannot add more users (Limit Reached)...";
        return;
    }

    bool flag = false;
    while (!flag)
    {
        cout << "\nEnter Username: ";
        cin >> username;
        if (!checkusername(username)) // USERNAME VALIDATION
        {
            cout << "Invalid Username";
            cout << " (First Letter Must be Capital)." << endl;
            continue;
        }
        bool exists = false;
        for (int i = 0; i < userCount; i++)
        { // Conditon to check if username already exists or not
            if (userUsernames[i] == username)
            {
                exists = true;
                break;
            }
        }
        if (exists)
        {
            cout << "Username already exists. Pleease choose another.\n";
        }
        else
        {
            flag = true; // username is unique
        }
    }

    flag = false;
    while (!flag)

    {
        cout << "\nEnter Password: ";
        cin >> password;

        if (checkpassword(password)) // password validation
        {
            flag = true;
        }

        else
        {
            cout << "\nInvalid Password";
            cout << " (Password should include special Characters)." << endl;
        }
    }

    flag = false;
    while (!flag)

    {
        cout << "\nconfirm Password: ";
        cin >> confirmPassword;

        if (password == confirmPassword) //
        {
            cout << " Signed up successfully";
            flag = true;
        }
        else
        {
            cout << "Password is not same :(" << endl;
        }
    }
    userUsernames[userCount] = username;
    userPasswords[userCount] = password;
    userCount++;
}

// ----------------------------------------------------------------

bool userLogin()
{
    //  IF NO ACCOUNT SIGNED UP
    if (userCount == 0)
    {
        cout << "\nNo user found! You need to Sign up first.\n";
        return false;
    }

    string u, p;
    int idx = -1;

    cout << "\n\n\n \t\t\t  ============================================================== \n   ";
    cout << "       \t\t\t\t        LOG IN PAGE FOR USER                      ";
    cout << " \n\t\t\t  ==============================================================" << endl;

    //  USERNAME VALIDATION
    cout << "\nEnter Username: ";
    cin >> u;

    for (int i = 0; i < userCount; i++)
    {
        if (userUsernames[i] == u) // MATCHING ENTERED USERNAME WITH STORED USERNAME
        {
            idx = i;
            break;
        }
    }

    if (idx == -1)
    {
        cout << "\nIncorrect Username.\n";
        return false;
    }

    while (true)
    {
        cout << "Enter Password: ";
        cin >> p;

        if (p == userPasswords[idx]) //  CHECKING PASSWORD
        {
            cout << "\nUser Logged in Successfully!\n";
            return true;
        }
        else
        {
            cout << "Password does not match! Try again...\n";
        }
    }
}

// ----------------------------------------------------------------

void menu()
{
    string username, password;

    string choice;
    while (true)
    {
        cout << "\n\n1. Sign up as User" << endl;
        cout << "2. Login as User" << endl;
        cout << "3. Login as Admin" << endl;
        cout << "4. Exit" << endl;

        cout << "Enter your choice: ";
        cin >> choice;
        // 3  checkChoice(choice);
        //  validation for choice
        system("cls");
        header();
        if (choice == "1")
        {
            userSignup();
            system("cls");
            header();
        }
        else if (choice == "2")
        {
            if (userLogin())
            {
                system("cls");
                header();
                userMenu();
                system("cls");
                header();
            }
        }
        else if (choice == "3")
        {
            if (login())
            {
                system("cls");
                header();
                adminmenu();
                system("cls");
                header();
            }
        }
        else if (choice == "4")
        {
            cout << "Program Exited." << endl;
            break; // Program will be exited.
        }
        else
        {
            cout << "Invalid choice! " << endl; // If choice is invalid
        }
    }
}

// ----------------------------------------------------------------

void userMenu()
{
    string choice = "0";
    while (choice != "6")
    {
        cout << "\n ===============\n|   USER MENU   | \n ===============";
        cout << "\n\n1. Add Product\n";
        cout << "2. Search Product\n";
        cout << "3. View Product\n";
        cout << "4. Calculate Bill\n";
        cout << "5. Logout\n";
        cout << "Enter Choice: ";
        cin >> choice;
        checkChoice(choice); //  validation

        if (choice == "1")
        {
            system("cls");
            header();
            addProduct();
            system("cls");
            header();
        }
        else if (choice == "2")
        {
            system("cls");
            header();
            searchProduct();
        }
        else if (choice == "3")
        {
            viewProduct();
            system("cls");
            header();
        }
        else if (choice == "4")
        {
            system("cls");
            header();
            bill();
        }
        else if (choice == "5")
        {
            cout << "\nLogging out...\n";
            system("cls");
            break; // return to main menu
        }
        else
        {
            cout << "\nInvalid Choice! (Should be between (1-5)).\n";
        }
    }
}

// ----------------------------------------------------------------

void adminmenu() // MAIN MENU FOR ADMIN FUNCTION
{
    string choice = "0";

    while (choice != "9")
    {
        cout << "\n|--------------WELCOME ADMIN--------------|" << endl;
        cout << "" << endl;
        cout << "1. Add New Product" << endl;
        cout << "2. View Product" << endl;
        cout << "3. Search Product" << endl;
        cout << "4. Update Product" << endl;
        cout << "5. Delete Product" << endl;
        cout << "6. Add Employee" << endl;
        cout << "7. View Employee" << endl;
        cout << "8. Logout\n";
        cout << "Enter your choice: ";
        cin >> choice;
        checkChoice(choice); // validation

        if (choice == "1")
        {
            system("cls");
            header();
            addProduct();
            system("cls");
            header();
        }
        else if (choice == "2")
        {
            system("cls");
            header();
            viewProduct();
            system("cls");
            header();
        }
        else if (choice == "3")
        {
            system("cls");
            header();
            searchProduct();
            system("cls");
            header();
        }
        else if (choice == "4")
        {
            system("cls");
            header();
            updateProduct();
            system("cls");
            header();
        }
        else if (choice == "5")
        {
            system("cls");
            header();
            deleteProduct();
            system("cls");
            header();
        }
        else if (choice == "6")
        {
            addEmployee();
            system("cls");
            header();
        }
        else if (choice == "7")
        {
            viewEmployee();
            system("cls");
            header();
        }
        else if (choice == "8")
        {
            cout << "Logging out..." << endl;
            system("cls");
            header();
            break;
        }
        else
        {
            cout << "Invalid choice! (should be between (1-8) ) " << endl;
            menu();
        }
    }
}

// ----------------------------------------------------------------

void searchProduct() // FUNCTION TO search Product
{
    if (proCount == 0) // if no product is added
    {
        cout << "RECORD NOT FOUND :(" << endl;
        return;
    }
    bool found = false;
    string id;
    cout << "Enter Product ID to search: ";
    cin >> id;
    for (int i = 0; i < proCount; i++)
    {
        if (proID[i] == id)
        {
            found = true;
            cout << "Product Found:" << endl;
            cout << setw(30) << "ID " << setw(30) << "Name " << setw(30) << "Price " << setw(30) << "Quantity " << endl;
            cout << setw(30) << proID[i] << setw(30) << proName[i] << setw(30) << proprice[i] << setw(30) << proQuantity[i] << endl;
        }
    }
    if (!found)
    {
        cout << "No Product with ID " << id << " Found :(" << endl;
    }
    int temp;
    cout << "\nEnter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}

// --------------------------------------------------------------

void bill() // FUNCTION TO CALCULATE BILL
{
    float total = 0;
    int qty[MAX_PRO];
    float finalPrice[MAX_PRO];

    if (proCount == 0)
    {
        cout << "RECORD NOT FOUND :(" << endl;
        return;
    }
    for (int i = 0; i < proCount; i++)
    {
        cout << "\n\n\n \t\t\t  ============================================================== \n   ";
        cout << "       \t\t\t\t                BILL                             ";
        cout << " \n\t\t\t  ==============================================================" << endl;
        cout << "Product ID = " << proID[i] << endl;
        cout << "Price of " << proName[i] << " = " << proprice[i] << " rs" << endl;
        cout << "Available Quantity" << " = " << proQuantity[i] << endl;

        cout << "Enter the quantity of " << proName[i] << " : " << endl;
        cin >> qty[i];

        finalPrice[i] = qty[i] * proprice[i];
    }

    for (int i = 0; i < proCount; i++)
    {
        total = total + finalPrice[i];
    }
    cout << endl
         << "Total Bill: " << total << " rs" << endl;
    int temp;
    cout << endl
         << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}

// ----------------------------------------------------------------

void addProduct() // FUNCTION TO ADD PRODUCT
{
    cout << "How many Products you want to Enter: ";
    cin >> n;
    if (n > MAX_PRO)
    {
        cout << "Cannot Add More Than 50 Products, TRY AGAIN!";
    }

    for (int i = 0; i < n; i++) // loop to add products.
    {
        cout << "Product " << i + 1 << endl;
        cout << "Enter Product ID : ";
        cin >> proID[proCount];
        checkChoice(proID[proCount]);

        cout << "Enter product name: ";
        cin >> proName[proCount];

        cout << "Enter product price : ";
        cin >> proprice[proCount];
        checkChoice(proprice[proCount]);

        cout << "Enter product quantity : ";
        cin >> proQuantity[proCount];
        checkChoice(proQuantity[proCount]);
        cout << endl;

        proCount++;
        cout << "PRODUCTS ADDED SUCCESSFULLY :)" << endl;
        cout << "            __________________________" << endl;
    }
    int temp;
    cout << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}

// -----------------------------------------------------------------

void viewProduct() // FUNCTION TO VIEW PRODUCT
{
    if (proCount == 0)
    {
        cout << "RECORD NOT FOUND :(" << endl;
        return;
    }
    cout << "\n\n\n \t\t\t  ============================================================== \n   ";
    cout << "       \t\t\t\t            PRODUCT LIST                          ";
    cout << " \n\t\t\t  ==============================================================" << endl;
    cout << "Total products: " << proCount << endl;

    cout << setw(20) << "Product " << setw(20) << " Product ID " << setw(20) << "Name " << setw(20) << "Price " << setw(20) << "Available Quantity " <<endl;
    for (int i = 0; i < proCount; i++)
    {
        cout <<endl << setw(20) << i + 1 << setw(20) << proID[i] << setw(20) << proName[i] << setw(20) << proprice[i] << setw(20) << proQuantity[i] << endl;
    }
    int temp;
    cout << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}

// ----------------------------------------------------------------

void updateProduct() // FUNCTION TO update Product
{
    if (proCount == 0)
    {
        cout << "RECORD NOT FOUND :(" << endl;
        return;
    }
    string id;
    cout << "Enter Product ID to update : ";
    cin >> id;
    bool found = false;

    for (int i = 0; i < proCount; i++)
    {
        if (proID[i] == id) // if ID found
        {
            found = true;
            cout << "\nProduct Found" << endl;
            cout << "Current name: " << proName[i] << endl;
            cout << "Current price: " << proprice[i];
            cout << endl;
            cout << "Quantity: " << proQuantity[i] << endl;
            cout << "Enter new name: ";
            cin >> proName[i];
            cout << "Enter new Price : ";
            cin >> proprice[i];
            checkChoice(proprice[i]);
            cout << "Enter new Quantity: ";
            cin >> proQuantity[i];
            checkChoice(proQuantity[i]);

            cout << endl
                 << "UPDATED SUCCESSFULLY :)"<<endl;
        }
    }
    if (!found)
    {
        cout << "No Product with ID " << id << " found :(" << endl;
    }
    int temp;
    cout << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}

// -----------------------------------------------------------------

void deleteProduct() // FUNCTION TO delete Product
{
    if (proCount == 0)
    {
        cout << "RECORD NOT FOUND :(" << endl;
        return;
    }
    string id;
    cout << "Enter Product ID to Delete: ";
    cin >> id;
    checkChoice(id);

    bool found = false;
    for (int i = 0; i < proCount; i++)
    {
        if (proID[i] == id)
        {
            found = true; // if ID found

            for (int j = i; j < proCount - 1; j++)
            {
                proID[j] = proID[j + 1];
                proName[j] = proName[j + 1];
                proprice[j] = proprice[j + 1];
            }

            proCount--;

            cout << endl
                 << "PRODUCT DELETED SUCCESSFULLY :)" << endl;
        }
    }
    if (!found) // if ID not found
    {
        cout << "RECORD NOT FOUND :(" << endl;
    }
    int temp;
    cout << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}
// ------------------------------------------------------------------------

bool checkusername(string username) // FUNCTION TO CHECK FIRST LETTER IS CAPITAL OR NOT
{
    int i = 0;
    bool isFound = false;
    for (int i = 0; i < 1; i++)
    {
        if (username[i] >= 'A' && username[i] <= 'Z')
        {
            isFound = true;
        }
    }
    return isFound;
}
// -----------------------------------------------------------------

// FUNCTION TO CHECK PASSWORD INCLUDES SPECIAL CHARACTER
bool checkpassword(string password)
{
    bool isFound = false;
    for (int i = 0; password[i] != '\0'; i++)
    {
        if ((password[i] >= '!' && password[i] <= '/') || (password[i] >= ':' && password[i] <= '@') || (password[i] >= '[' && password[i] <= '`') || (password[i] >= '{' && password[i] <= '~'))
        {
            return true;
        }
    }
    return false;
}
// ----------------------------------------------------------------
bool checkChoice(string choice) // function for choice validation
{
    for (int i = 0; i < choice.length(); i++)
    {
        if (choice[i] >= '0' && choice[i] <= '9')
        {
            return true;
        }
        else
        {
            cout << "Invalid choice! input should be a number. ";
            return false;
        }
    }
}
// --------------------------------------------

void header() // function for header
{

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 4);
    Sleep(150);
    cout << "                                              _____  _" << endl;
    Sleep(150);
    cout << "                                             /  ___|| |" << endl;
    Sleep(150);
    cout << "                                             \\ `--. | |_   __   _  _   ___" << endl;
    Sleep(150);
    cout << "                                              `--. \\| __| /  \\ | |/ | / _ \\" << endl;
    Sleep(150);
    cout << "                                             /\\__/ /| |_ | () ||  /  |  __/" << endl;
    Sleep(150);
    cout << "                                             \\____/  \\__| \\__/ |_|    \\___|" << endl;

    SetConsoleTextAttribute(hConsole, 5);
    Sleep(150);
    cout << "      ___  ___                                                           _      _____              _" << endl;
    Sleep(150);
    cout << "      |  \\/  |                                                          | |    /  ___|            | |" << endl;
    Sleep(200);
    cout << "      | .  . |  __ _  _ __    __ _   __ _   ___  _ __ ___    ___  _ __  | |_   \\ `--.  _   _  ___ | |_   ___   _ __ ___" << endl;
    Sleep(200);
    cout << "      | |\\/| | / _` || '_ \\  / _` | / _` | / _ \\| '_ ` _ \\  / _ \\| '_ \\ | __|   `--. \\| | | |/___|| __| / _ \\ | '_ ` _ \\    " << endl;
    Sleep(200);
    cout << "      | |  | || (_| || | | || (_| || (_| ||  __/| | | | | ||  __/| | | || |_   /\\__/ /| |_| |\\___ | |_ |  __/ | | | | | |     " << endl;
    Sleep(200);
    cout << "      \\_|  |_/ \\__,_||_| |_| \\__, | \\__,_| \\___||_| |_| |_| \\___||_| |_| \\__|  \\____/  \\__, ||___/ \\__| \\___| |_| |_| |_|   " << endl;
    Sleep(200);
    cout << "                                | |                                                       | |" << endl;
    Sleep(150);
    cout << "                              __| |                                                     __| | " << endl;
    Sleep(150);
    cout << "                             |____'                                                    |____'  \n\n"
         << endl;
    Sleep(250);
    SetConsoleTextAttribute(hConsole, 7);
}

bool checkChoice(float choice) // function for choice validation
{
    if (choice < 0)
    {
        cout << "Invalid choice! input should be greater than 0. ";
        return false;
    }
    else
    {
        return true;
    }
}

bool checkChoice(int choice) // function for choice validation
{

    if (choice < 0)
    {
        cout << "Invalid choice! input should be greater than 0. ";
        return false;
    }
    else
    {
        return true;
    }
}

// FILE HANDLING FUNCTIONS
/*
void loadData()
{
    ifstream f("data.txt");
    if (f)
    {
        f >>
    }
}*/

void saveUsersToFile()
{
    ofstream file("users.txt");
    for (int i = 0; i < userCount; i++)
    {
        file << userUsernames[i] << "," << userPasswords[i] << "\n";
    }
    file.close();
}

void loadUsersFromFile()
{
    ifstream file("users.txt");
    if (!file) // File doesn't exist
        return;

    userCount = 0;
    while (file >> userUsernames[userCount] >> userPasswords[userCount])
    {
        userCount++;
        if (userCount >= MAX_USERS)
            break;
    }

    file.close();
}
//-----------
void viewEmployee()
{
    if (salesmanCount == 0)
    {
        cout << "No employees found!\n";
        return;
    }

    cout << "\n-------- EMPLOYEE LIST --------\n";
    cout << setw(5) << "No."
         << setw(20) << "Name"
         << setw(15) << "ID"
         << setw(20) << "Salary" << endl;

    for (int i = 0; i < salesmanCount; i++)
    {
        cout << setw(5) << i + 1
             << setw(20) << employeeName[i]
             << setw(15) << employeeID[i]
             << setw(20) << employeeSalary[i] << endl;
    }

    int temp;
    cout << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}
//----------

void addEmployee()
{
    if (salesmanCount >= MAX_USERS)
    {
        cout << "Cannot add more employees (Limit reached).\n";
        return;
    }

    cout << "Enter Employee Name: ";
    cin >> employeeName[salesmanCount];

    cout << "Enter Employee ID: ";
    cin >> employeeID[salesmanCount];

    cout << "Enter Employee Position: ";
    cin >> employeeSalary[salesmanCount];

    salesmanCount++;
    cout << "Employee added successfully!\n";

    int temp;
    cout << "Enter any number to return to main menu: ";
    cin >> temp;
    cout << "____________________________________" << endl;
}
